# A Forest in Your Cup

A visual essay by Ye Liu about coffee, the EU Deforestation Regulation, and the costs of demonstrating compliance for small farmers.

This repository contains the editable article, page-building scripts, and the complete rendered static site. It uses Node.js built-in modules and requires no package installation.

## Build and preview

Run these commands from the repository directory with Node.js installed:

```sh
node build.mjs
node preview.mjs
```

Open [the local preview](http://127.0.0.1:4173). Stop the preview server with Ctrl+C.

The build synchronizes the reading-view data in `dist/content.js` from `blog-source.json`, then generates `dist/index.html` using the existing layout builder. It does not rewrite the article source.

## Editing

- `blog-source.json` contains the article, references, image credits, and datasets. Article sections contain both `proseHtml` for the main page and `html` for the reading view; update both when changing shared text.
- `index-v1-source.html` supplies layout fragments used by the current builder. It is an active build input despite its historical filename.
- `build-v2.mjs` assembles the main page, and `design-v3.mjs` applies its cover design.
- `dist/` contains the site styles, interactive scripts, photographs, chart assets, and downloadable CSV files. Edit these files directly when changing those parts of the site.

Run `node build.mjs` after changing the article or page-building inputs. If chart data changes, also update the corresponding downloadable files in `dist/data/` and any separately authored chart assets.

## Standalone site

The complete `dist/` directory is the static site output. A static web server can serve that directory without Node.js, a database, or a build step. Keep its directory structure intact so local styles, scripts, images, and data links resolve correctly. External reference links still require internet access.

Keep `dist/` in version control: the builder regenerates only `index.html` and `content.js`; it does not recreate the other authored site files. Image provenance and usage notes are recorded in `dist/assets/sources.json` and in the article's credits.
