import fs from 'node:fs';
import { applyCoverV3 } from './design-v3.mjs';
const path='dist/index.html';
if(!fs.existsSync('index-v1-source.html')) fs.copyFileSync(path,'index-v1-source.html');
const old=fs.readFileSync('index-v1-source.html','utf8');
const d=JSON.parse(fs.readFileSync('blog-source.json','utf8'));
const sections=Object.fromEntries([d.intro,...d.sections,d.conclusion].map(s=>[s.id,s]));
const refs=Object.fromEntries(d.references.map(r=>[r.id,r]));
const paras=id=>(sections[id].proseHtml.match(/<p\b[\s\S]*?<\/p>/g)||[]).map(p=>p.replace('<p','<p data-narrative="true"'));
const prose=(id,start=0,end)=>`<div class="chapter-prose" data-prose="${id}">${paras(id).slice(start,end).join('\n')}</div>`;
const link=(id,label)=>`<a href="${refs[id].url}" target="_blank" rel="noopener">${label}</a>`;
const caption=(num,title,source,note='')=>`<figcaption class="evidence-caption"><strong>Figure ${num}. ${title}.</strong> ${source}${note?' '+note:''}</figcaption>`;
const heading=(num,kicker,title)=>`<div class="chapter-heading"><p class="eyebrow">${num} / ${kicker}</p><h2>${title}</h2></div>`;
const chunk=(from,to)=>old.slice(old.indexOf(from),old.indexOf(to,old.indexOf(from)));
const figures=[];
const imports=d.datasets.imports.filter(r=>r.figure==='germany-imports');
figures.push(`<figure class="imports-figure analytic-figure reveal" id="trade-chart"><div class="figure-eyebrow">FIGURE 01 / THE MARKET GATEWAY</div><div class="visual-heading"><h3>Germany is a major<br><em>gateway for coffee.</em></h3><p>2025 imports from outside the EU<br><strong>Thousand tonnes</strong></p></div><div class="imports-chart" aria-label="Selected EU member states, 2025 extra-EU coffee imports">${imports.map((r,i)=>`<button class="import-row ${i===0?'selected':''}" data-import="${i}" aria-pressed="${i===0}"><span class="import-country">${r.reporter}</span><span class="import-track"><span style="--amount:${r.value/1100000*100}%"></span></span><strong>${(r.value/1000).toLocaleString('en',{maximumFractionDigits:1})}</strong></button>`).join('')}<div class="import-axis"><span>0</span><span>550</span><span>1,100</span></div></div><p class="chart-insight" id="import-insight" aria-live="polite">Germany accounts for 34% of all extra-EU coffee imports. Imports are not household consumption.</p>${caption('01','A large market gives the rule reach',`Original chart; data: ${link('eurostat','Eurostat (2026), ds-045409')}.`,'Selected member states; CN 090111, 090112, 090121, 090122 and 090190.')}<details class="figure-data"><summary>View exact values & download data <span>+</span></summary><table><thead><tr><th>Importer</th><th>Tonnes</th></tr></thead><tbody>${imports.map(r=>`<tr><th>${r.reporter}</th><td>${r.value.toLocaleString('en')}</td></tr>`).join('')}</tbody></table><a href="data/chart-data.csv" download>Download source-labelled CSV ↓</a></details></figure>`);
figures.push(`<figure class="policy-timeline analytic-figure reveal" id="policy-dates"><div class="figure-eyebrow">FIGURE 02 / READ THE DATES CORRECTLY</div><h3>One date tests the land.<br><em>The others start the duties.</em></h3><ol><li><span class="date-dot"></span><time>31 DEC 2020</time><h4>Land-use cutoff</h4><p>Later forest-to-agriculture conversion fails the coffee test.</p></li><li><span class="date-dot"></span><time>30 DEC 2026</time><h4>Large & medium operators</h4><p>Main duties begin for green and roasted coffee.</p></li><li><span class="date-dot"></span><time>30 JUN 2027</time><h4>Most micro & small operators</h4><p>This is not extra time for every overseas small farm.</p></li></ol>${caption('02','Cutoff is different from application',`Original timeline; ${link('law','EUDR')} and ${link('overview','European Commission')}.`,'Not spaced to scale. New coffee-extract scope: 30 December 2027. Checked 28 October 2026.')}</figure>`);
let country=chunk('    <div class="country-layout">','    <div class="source-line">');
country=country.replace('<small>USDA, May 2026 · Photograph is illustrative.</small>',`<p class="photo-source"><strong>Coffee on the branch.</strong> <a href="${d.photos.images.find(p=>p.file==='photo-cherries.jpg').source_url}" target="_blank" rel="noopener">Daniel Reche / Pexels</a>. Illustrative; not a documented Ethiopian farm. Data: ${link('usda','USDA (2026)')}.</p>`);
country=country.replace('<small>Eurostat, 2025 data · Imports ≠ consumption.</small>',`<p class="photo-source"><strong>A port at the buying end.</strong> <a href="${d.photos.images.find(p=>p.file==='photo-port.jpg').source_url}" target="_blank" rel="noopener">Frank Rietsch / Pexels</a>. Hamburg; cargo not identified as coffee. Data: ${link('eurostat','Eurostat (2026)')}.</p>`);
country=country.replace('ONE CONNECTED<br>STORY','TRADE LINK<br>NOT A SHIPPING ROUTE');
const route=chunk('    <div class="route-tabs"','    <div class="proof-bottom">');
let survey=chunk('    <div class="chart-paper reveal">','  </section>');
survey=survey.replace('<span>THE CAPACITY GAP</span>','<span>FIGURE 04 / THE CAPACITY GAP</span>');
survey=survey.replace('<div class="chart-foot">',`<div class="chart-foot">`);
survey=survey.replace('IGC working paper · February 2026',link('igc','IGC working paper · February 2026'));
const choices=chunk('<div class="choice-switch"','<div class="choice-footer">');
const thumbs=(file,title,credit)=>`<figure class="photo-inset"><img src="assets/${file}" loading="lazy" alt="${title}"><figcaption><strong>${title}.</strong> <a href="${d.photos.images.find(p=>p.file===file).source_url}" target="_blank" rel="noopener">${credit} / Pexels</a>. Illustrative; location not established.</figcaption></figure>`;
let header=old.slice(0,old.indexOf('  <div class="ticker"'));

header=header.replace('A journey into the hidden costs of a better cup.','The EU Deforestation Regulation and its hidden costs for small farmers.');
header=header.replace('Read the full essay','Reading view');
header=header.replace('A FOREST IN A CUP / A VISUAL METAPHOR',`A FOREST IN A CUP · CONCEPTUAL COMPOSITION<br><a href="${d.photos.images[0].source_url}" target="_blank" rel="noopener">FOREST PHOTO: LAURA MEINHARDT / PEXELS</a>`);
header=header.replace('<link rel="stylesheet" href="styles.css">','<link rel="stylesheet" href="styles.css"><link rel="stylesheet" href="article-v2.css"><link rel="stylesheet" href="visuals.css">');
header=header.replace('<script src="app.js" defer></script>','<script src="app.js" defer></script><script src="visuals.js" defer></script><script src="article-v2.js" defer></script>');
let main=`
<div class="story-meta"><span>WORDS BY YE LIU</span><span id="word-count">${d.wordCount} NARRATIVE WORDS</span><span>28 OCTOBER 2026</span><a href="#sources">SOURCES ↓</a></div>
<section class="narrative-section section-pad" id="question">${heading('00','THE QUESTION BEHIND THE CUP','Can coffee be truly<br><em>deforestation-free?</em>')}${prose('introduction')}</section>
<section class="origins section-pad" id="origins">${heading('01','TWO COUNTRIES, ONE CUP','Grown here.<br><em>Governed there.</em>')}${country}<p class="evidence-caption trade-flow-note"><strong>Two ends of one relationship.</strong> 58,721 tonnes rounded from 58,721.2; ${link('wits','WITS / UN Comtrade')}, 2025, HS 090111. Not a shipment route.</p>${prose('two-countries')}${figures[0]}</section>
<section class="rules-story section-pad" id="rules-story">${heading('02','WHAT THE RULE ACTUALLY REQUIRES','A forest rule becomes<br><em>a test of evidence.</em>')}${prose('rules')}${figures[1]}</section>
<section class="proof section-pad" id="proof"><figure class="route-figure"><div class="proof-heading"><p class="eyebrow">FIGURE 03 / FOLLOW THE BEAN. FOLLOW THE PROOF.</p><h2>A bean travels.<br><em>Its story must travel, too.</em></h2><p>Select a stop to follow the evidence work.</p></div>${route}${caption('03','Evidence follows the coffee',`Original conceptual flowchart; ${link('roles','Commission roles guidance')} and ${link('due','due-diligence guidance')}.`,'Legal responsibility at EU market entry does not determine who bears every cost.')}</figure></section>
<section class="forest-interlude" id="forest"><img src="assets/photo-forest.jpg" alt="Illustrative misty forest canopy, location not established" loading="lazy"><div class="interlude-content"><p class="eyebrow">03 / THE ENVIRONMENTAL CASE</p><h2>A cleaner cup should mean<br><em>a forest still standing.</em></h2></div><p class="image-credit"><strong>A forest still standing.</strong> <a href="${d.photos.images[0].source_url}" target="_blank" rel="noopener">Laura Meinhardt / Pexels</a>. Illustrative; location not established.</p></section>
<section class="narrative-section section-pad environment-prose">${prose('environment')}</section>
<section class="smallholder-section section-pad" id="evidence">${heading('04','THE ETHIOPIAN SMALLHOLDER TEST','Protecting a forest.<br><em>Proving you did.</em>')}${prose('ethiopia',0,2)}<div class="survey-layout"><div class="survey-context"><p class="figure-eyebrow">EVIDENCE / SELF-REPORTED CAPACITY</p><span class="survey-big">600</span><p>Cooperative-member households<br>in selected districts of<br>southwestern Ethiopia.</p><span class="survey-gap">1.06 <small>POINTS</small></span><p>Between demonstrating deforestation-free production and paying compliance costs.</p><p class="evidence-caption">A descriptive gap, not a causal estimate. The sample is not nationally representative.</p></div>${survey}</div><p class="evidence-caption survey-caption"><strong>Figure 04. Confidence is not the same as capacity.</strong> Original chart, ${link('igc','Berihun (2026), Table 3, printed p. 25')}. Five-point self-report scale; values are not verified compliance scores.</p>${prose('ethiopia',2)}</section>
<section class="buyer-section section-pad" id="buyer">${heading('05','THE GERMAN BUYER TEST','The duty sits here.<br><em>The bill can travel.</em>')}${prose('germany',0,2)}<div id="cost-visual"></div>${prose('germany',2)}</section>
<section class="map-section section-pad" id="blindspot">${heading('06','WHEN THE SATELLITE SEES THE WRONG THING','A greener-looking farm.<br><em>A harder-to-read map.</em>')}${prose('maps',0,2)}<div id="classification-visual"></div>${prose('maps',2)}</section>
<section class="choices section-pad" id="choices">${heading('07','A CLEAN LEDGER OR HEALTHIER FORESTS?','The same rule.<br><em>Different possible outcomes.</em>')}${prose('trade',0,2)}<figure class="pathways-figure analytic-figure"><p class="figure-eyebrow">FIGURE 07 / TEST THE CAUSAL CHAIN</p><h3>What changes when<br><em>buyers share the work?</em></h3>${choices}${caption('07','Two conditional pathways',`Original synthesis of ${link('wur','ten Hove et al. (2025)')} and ${link('leakage','Yarlagadda et al. (2025)')}.`,'Illustrative mechanisms, not measured coffee outcomes. The latter study models palm oil and soy.')}</figure>${prose('trade',2)}</section>
<section class="forward-v2 section-pad" id="forward">${heading('08','WHAT A FAIRER IMPLEMENTATION WOULD DO','Keep the standard.<br><em>Build the ability to meet it.</em>')}${prose('solutions',0,4)}<figure class="scorecard analytic-figure" id="outcomes-scorecard"><p class="figure-eyebrow">FIGURE 08 / MEASURE THE OUTCOME, NOT JUST THE PAPERWORK</p><h3>What would success<br><em>actually look like?</em></h3><div class="scorecard-grid"><div><span>01 / ACCESS</span><h4>Smallholders stay</h4><p>Track supplier retention and exits.</p></div><div><span>02 / FAIRNESS</span><h4>Costs are shared</h4><p>Track farmer-paid costs and farmgate returns.</p></div><div><span>03 / CORRECTION</span><h4>Errors get resolved</h4><p>Track appeal access and correction times.</p></div><div><span>04 / FORESTS</span><h4>Conversion falls</h4><p>Independently verify land-use change.</p></div></div>${caption('08','An outcome scorecard',`Original synthesis of ${link('wur','ten Hove et al. (2025)')} and ${link('odi','Legesse et al. (2026)')}.`,'Proposed evaluation measures, not observed results. Registration counts alone cannot establish forest protection.')}</figure>${prose('solutions',4)}</section>
<section class="closing" id="conclusion"><div class="closing-top"><p class="eyebrow">CONCLUSION / BEYOND THE LAST SIP</p><button class="inline-link light" data-read="all">Open reading view ↗</button></div><h2>Keep the forest.<br><em>Keep the farmer.</em></h2>${prose('conclusion')}</section>
<section class="sources section-pad" id="sources"><div class="sources-top"><div><p class="eyebrow">THE READING DESK</p><h2>Behind the story.</h2></div><p>Evidence and image credits.<br>Evidence date: 28 October 2026.</p></div><details class="source-details" open><summary>References & further reading <span>+</span></summary><div id="reference-list"></div></details><details class="source-details"><summary>Photography & visual notes <span>+</span></summary><div id="photo-credits"></div><p class="visual-note">The cover is a conceptual composition. Photographs illustrate the story, rather than documenting the Ethiopian farms or coffee shipments discussed. The analytical graphics are original designs for this blog, using the cited evidence; conceptual diagrams are labelled separately from measured data.</p></details><div class="download-row"><span>EXPLORE THE NUMBERS</span><a href="data/chart-data.csv" download>Trade data CSV ↓</a><a href="data/survey-data.csv" download>Survey data CSV ↓</a></div></section>
</main>
`;
const concise=[
 ['<p>Smallholders produce roughly 90% of Ethiopia’s coffee, usually on plots smaller than half a hectare.</p>',''],
 ['<p>A major importing and processing hub, where European market rules meet purchasing decisions.</p>',''],
 ['<p class="evidence-caption trade-flow-note"><strong>Two ends of one relationship.</strong> 58,721 tonnes rounded from 58,721.2;','<p class="evidence-caption trade-flow-note"><strong>Trade link.</strong> Rounded from 58,721.2 tonnes;'],
 ['Germany accounts for 34% of all extra-EU coffee imports. Imports are not household consumption.','Germany: 34% of extra-EU imports. Imports are not consumption.'],
 ['Figure 01. A large market gives the rule reach.','Figure 01. Europe’s coffee gateways.'],
 ['Selected member states; CN 090111, 090112, 090121, 090122 and 090190.','Selected states; product codes in CSV.'],
 ['Later forest-to-agriculture conversion fails the coffee test.','No later forest-to-farm conversion.'],
 ['Main duties begin for green and roasted coffee.','Duties begin: green and roasted coffee.'],
 ['This is not extra time for every overseas small farm.','Not an extension for all overseas farms.'],
 ['Not spaced to scale. New coffee-extract scope: 30 December 2027. Checked 28 October 2026.','Not to scale. Coffee extracts: 30 December 2027.'],
 ['Select a stop to follow the evidence work.','Select a stop.'],
 ['Map the producing plot and establish its land-use history. A coordinate must remain connected to the coffee that leaves the farm.','Map the plot, establish land-use history, and link both to its coffee.'],
 ['Legal responsibility at EU market entry does not determine who bears every cost.','Legal duty ≠ cost incidence.'],
 ['Cooperative-member households<br>in selected districts of<br>southwestern Ethiopia.','Cooperative households<br>Southwestern Ethiopia'],
 ['Between demonstrating deforestation-free production and paying compliance costs.','Production proof vs. paying costs'],
 ['A descriptive gap, not a causal estimate. The sample is not nationally representative.','Descriptive, not causal.<br>Not nationally representative.'],
 ['<p id="gap-note" class="gap-note" aria-live="polite">These are perceptions, not independently verified compliance scores.','<p id="gap-note" class="gap-note" aria-live="polite">Self-reported, not verified compliance.'],
 ['Figure 04. Confidence is not the same as capacity.','Figure 04. Confidence and capacity.'],
 ['Five-point self-report scale; values are not verified compliance scores.','Five-point self-report scale.'],
 ['Buyers help fund mapping, record keeping and local verification.','Buyers co-finance credible evidence.'],
 ['A supported cooperative can supply credible evidence and retain buyers.','Supported cooperatives can retain buyers.'],
 ['Dependable income can make forest-compatible production more attractive.','Dependable income can support forest-compatible farming.'],
 ['Illustrative mechanisms, not measured coffee outcomes. The latter study models palm oil and soy.','Mechanisms, not measured outcomes; leakage study covers oil crops.'],
 ['Proposed evaluation measures, not observed results. Registration counts alone cannot establish forest protection.','Proposed measures, not results. Registrations ≠ forest protection.'],
 ['<p class="figure-eyebrow">FIGURE 08 / MEASURE THE OUTCOME, NOT JUST THE PAPERWORK</p>','<p class="figure-eyebrow">FIGURE 08 / MEASURE WHAT MATTERS</p>'],
 ['<p class="figure-eyebrow">FIGURE 07 / TEST THE CAUSAL CHAIN</p>','<p class="figure-eyebrow">FIGURE 07 / TWO PATHWAYS</p>'],
 ['00 / THE QUESTION BEHIND THE CUP','00 / INTRODUCTION'],
 ['01 / TWO COUNTRIES, ONE CUP','01 / ORIGINS'],
 ['02 / WHAT THE RULE ACTUALLY REQUIRES','02 / THE RULE'],
 ['03 / THE ENVIRONMENTAL CASE','03 / THE ENVIRONMENT'],
 ['04 / THE ETHIOPIAN SMALLHOLDER TEST','04 / SMALLHOLDERS'],
 ['05 / THE GERMAN BUYER TEST','05 / BUYERS'],
 ['06 / WHEN THE SATELLITE SEES THE WRONG THING','06 / MAPPING'],
 ['07 / A CLEAN LEDGER OR HEALTHIER FORESTS?','07 / CONSEQUENCES'],
 ['08 / WHAT A FAIRER IMPLEMENTATION WOULD DO','08 / SOLUTIONS'],
 ['CONCLUSION / BEYOND THE LAST SIP','CONCLUSION'],
 ['FIGURE 03 / FOLLOW THE BEAN. FOLLOW THE PROOF.','FIGURE 03 / TRACEABILITY'],
 ['FIGURE 02 / READ THE DATES CORRECTLY','FIGURE 02 / POLICY DATES'],
 ['EVIDENCE / SELF-REPORTED CAPACITY','SURVEY / CAPACITY'],
 ['<p class="evidence-caption">Descriptive, not causal.<br>Not nationally representative.</p>',''],
 ['Five-point self-report scale.</figcaption>','</figcaption>'],
 ['<p class="eyebrow">FIGURE 08 / MEASURE WHAT MATTERS</p>','<p class="eyebrow">FIGURE 08 / OUTCOMES</p>']
];
for(const [before,after] of concise)main=main.replaceAll(before,after);
main=main.replace('<div id="reference-list"></div>',`<div id="reference-list">${d.references.map(ref=>`<div class="ref-entry" id="${ref.anchor}">${ref.html}</div>`).join('')}</div>`);
main=main.replace('<div class="survey-layout">','<figure class="survey-figure"><div class="survey-layout">');
main=main.replace(/<p class="evidence-caption survey-caption">([\s\S]*?)<\/p>/,'<figcaption class="evidence-caption survey-caption">$1</figcaption></figure>');
let tail=old.slice(old.indexOf('<footer>'));
tail=tail.replace('<a href="#proof"><small>02</small>The proof','<a href="#rules-story"><small>02</small>The rule & the proof');
tail=tail.replace('<a href="#blindspot"><small>05</small>','<a href="#buyer"><small>05</small>Who pays?<span>↗</span></a><a href="#blindspot"><small>06</small>');
tail=tail.replace('<small>06</small>Two possible futures','<small>07</small>Two possible futures').replace('<small>07</small>A way forward','<small>08</small>A way forward');
tail=tail.replace('This visual story works best with JavaScript. All images and the main story remain available; download the source data above.','The complete article and data charts are available below. Enable JavaScript to explore the interactive diagrams.');
fs.writeFileSync(path,applyCoverV3(header+main+tail,d));
console.log(`Built visible narrative: ${[d.intro,...d.sections,d.conclusion].map(s=>paras(s.id).length).reduce((a,b)=>a+b,0)} paragraphs.`);
