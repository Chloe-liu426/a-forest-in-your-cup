export function applyCoverV3(html, data) {
  const forest = data.photos.images.find(photo => photo.file === 'photo-forest.jpg');
  html = html.replace(/<header class="masthead">[\s\S]*?<\/header>/, `<header class="cover-controls" aria-label="Page controls"><button class="motion-toggle" aria-pressed="false" title="Pause animations"><span aria-hidden="true">Ⅱ</span><span class="sr-only">Pause animations</span></button><button class="menu-toggle" aria-label="Open story chapters" aria-haspopup="dialog"><span></span><span></span></button></header>`);
  html = html.replace(/<div class="hero-topline">[\s\S]*?<\/div>/, '');
  html = html.replace(/<div class="hero-copy">[\s\S]*?<\/div><\/div>/, `<div class="hero-copy"><h1 id="hero-title" aria-label="A forest in your cup"><span class="title-first">A forest</span><span class="title-middle">in your</span><span class="title-last">cup.</span></h1></div>`);
  html = html.replace(/<span class="orbit-note note-one">[\s\S]*?<\/span>/, '');
  html = html.replace(/<span class="hand-note">[\s\S]*?<\/span>/, '');
  html = html.replace(/<span class="art-caption">[\s\S]*?<\/span>/, '');
  html = html.replace(/<div class="hero-bottom">[\s\S]*?<\/div>/, `<a class="cover-scroll" href="#question" aria-label="Enter the story"><svg viewBox="0 0 32 32" aria-hidden="true"><path d="M16 5v21M7 17l9 9 9-9"/></svg></a>`);
  html = html.replace('<div class="story-meta">', `<p class="cover-credit"><strong>A forest in a cup.</strong> Conceptual composition. Forest photograph: <a href="${forest.source_url}" target="_blank" rel="noopener">Laura Meinhardt / Pexels</a>; illustrative, location not established.</p><div class="story-meta">`);
  html = html.replace('<link rel="stylesheet" href="visuals.css">','<link rel="stylesheet" href="visuals.css"><link rel="stylesheet" href="cover-v3.css">');
  html = html.replaceAll('FIELDNOTES / THE ESSAY','A FOREST IN YOUR CUP / READING VIEW').replaceAll('FIELDNOTES / EXPLORE','A FOREST IN YOUR CUP / EXPLORE');
  html = html.replace('<a class="footer-brand" href="#top">FIELDNOTES <span>↗</span></a>','<a class="footer-brand" href="#top">A forest in your cup <span>↗</span></a>');

  return html;
}
