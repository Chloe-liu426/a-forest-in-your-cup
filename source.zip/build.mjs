import fs from 'node:fs';
import { fileURLToPath } from 'node:url';

// Keep the existing builder's relative paths anchored to this project.
process.chdir(fileURLToPath(new URL('.', import.meta.url)));

// Both the main page and reading view use the current article source.
const data = JSON.parse(fs.readFileSync('blog-source.json', 'utf8'));
fs.writeFileSync('dist/content.js', 'window.BLOG_DATA = ' + JSON.stringify(data) + ';\n');
await import('./build-v2.mjs');
